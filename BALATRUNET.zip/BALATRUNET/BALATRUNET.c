#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <conio.h>
#include <windows.h>

#define MAX_JUGADORES 4
#define MIN_JUGADORES 3
#define CARTAS_INICIALES 2
#define MAX_CARTAS 50

//colores ya que poker.h no agarro
#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define BLUE "\033[34m"
#define MAGENTA "\033[35m"
#define CYAN "\033[36m"
#define WHITE "\033[37m"
#define RESET "\033[0m"

//estructuras
typedef struct {
    int valor;
    int palo;
} Carta;

typedef struct {
    Carta cartas[MAX_CARTAS];
    int num_cartas;
    int eliminado;
    int puntos;
    int carta_especial_usada;
} Jugador;

//variables
Jugador jugadores[MAX_JUGADORES];
int num_jugadores;
int turno_actual = 0;
int direccion = 1;
int juego_terminado = 0;

void dibujar_carta(Carta c);
int valor_carta_puntos(Carta c);
void repartir_carta(int jugador);
void mostrar_mano(int jugador);
int calcular_puntos(int jugador);
void mostrar_estado();
void usar_carta_especial(int jugador);
void siguiente_turno();
int tiene_carta_especial_mas_alta();

// funciones


int valor_carta_puntos(Carta c) {
    if (c.valor >= 11) return 10;
    return c.valor;
}

Carta generar_carta_aleatoria() {
    Carta c;
    int r = rand() % 13 + 1;
    c.valor = r;
    c.palo = (rand() % 4) + 1;
    return c;
}

void repartir_carta(int jugador) {
    if (jugadores[jugador].num_cartas < MAX_CARTAS) {
        Carta c = generar_carta_aleatoria();
        jugadores[jugador].cartas[jugadores[jugador].num_cartas++] = c;
        jugadores[jugador].puntos = calcular_puntos(jugador);
    }
}

void dibujar_carta(Carta c) {
    const char* valor_str;
    switch(c.valor) {
        case 1: valor_str = "A"; break;
        case 11: valor_str = "J"; break;
        case 12: valor_str = "Q"; break;
        case 13: valor_str = "K"; break;
        default: {
            static char buf[3];
            snprintf(buf, sizeof(buf), "%d", c.valor);
            valor_str = buf;
            break;
        }
    }

    const char* palo_str;
    const char* color;
    switch(c.palo) {
        case 1: palo_str = "Corazones"; color = RED; break;
        case 2: palo_str = "Diamantes"; color = YELLOW; break;
        case 3: palo_str = "Treboles";  color = GREEN; break;
        case 4: palo_str = "Picas";     color = CYAN; break;
        default: palo_str = "Desconocido"; color = WHITE; break;
    }

    printf("%s%s de %s%s", color, valor_str, palo_str, RESET);
}

void mostrar_mano(int jugador) {
    printf("Mano Jugador %d: ", jugador + 1);
    for(int i = 0; i < jugadores[jugador].num_cartas; i++) {
        dibujar_carta(jugadores[jugador].cartas[i]);
        if (i < jugadores[jugador].num_cartas - 1) printf(", ");
    }
    printf(" | Puntos: %d\n", jugadores[jugador].puntos);
}

int calcular_puntos(int jugador) {
    int suma = 0;
    for (int i = 0; i < jugadores[jugador].num_cartas; i++) {
        suma += valor_carta_puntos(jugadores[jugador].cartas[i]);
    }
    return suma;
}

void mostrar_estado() {
    printf("\nEstado de la partida:\n\n");
    for (int i = 0; i < num_jugadores; i++) {
        printf("Jugador %d %s | Cartas: %d | ", i + 1, (jugadores[i].eliminado ? "(Eliminado)" : ""), jugadores[i].num_cartas);
        mostrar_mano(i);
    }
}

void siguiente_turno() {
    do {
        turno_actual += direccion;
        if (turno_actual < 0) turno_actual = num_jugadores - 1;
        if (turno_actual >= num_jugadores) turno_actual = 0;
        jugadores[turno_actual].carta_especial_usada = 0;
    } while (jugadores[turno_actual].eliminado);
}

void usar_carta_especial(int jugador) {
    int tiene_especial = 0;
    int indice_carta_especial = -1;

    for(int i=0; i<jugadores[jugador].num_cartas; i++) {
        int v = jugadores[jugador].cartas[i].valor;
        if (v == 11 || v == 12 || v == 13) {
            tiene_especial = 1;
            indice_carta_especial = i;
            break;
        }
    }

    if (!tiene_especial) {
        printf(RED "No tienes cartas especiales para usar.\n" RESET);
        return;
    }

    Carta especial = jugadores[jugador].cartas[indice_carta_especial];
    int siguiente = turno_actual + direccion;

    if (siguiente < 0) siguiente = num_jugadores - 1;
    if (siguiente >= num_jugadores) siguiente = 0;

    switch(especial.valor) {
        case 13:
            printf(MAGENTA "Carta especial K (King) usada: Se salta el turno del siguiente jugador %d.\n" RESET, siguiente + 1);
            turno_actual = siguiente;
            siguiente_turno();
            siguiente_turno();
            break;

        case 12:
            direccion *= -1;
            printf(MAGENTA "Carta especial Q (Queen) usada: Cambio de direccion del juego.\n" RESET);
            break;

        case 11:
            printf(MAGENTA "Carta especial J (Joker) usada: Penalizando jugador %d con cartas extra.\n" RESET, siguiente + 1);
            int cartas_a_agregar = (jugadores[siguiente].num_cartas % 2 == 0) ? 2 : 4;
            printf("Jugador %d recibe %d cartas extra.\n", siguiente + 1, cartas_a_agregar);
            for (int i = 0; i < cartas_a_agregar; i++) {
                repartir_carta(siguiente);
            }
            jugadores[siguiente].puntos = calcular_puntos(siguiente);
            if (jugadores[siguiente].puntos > 21) {
                printf(RED "Jugador %d se pasa de 21 y es eliminado.\n" RESET, siguiente + 1);
                jugadores[siguiente].eliminado = 1;
            }
            break;
    }

    for (int i = indice_carta_especial; i < jugadores[jugador].num_cartas - 1; i++) {
        jugadores[jugador].cartas[i] = jugadores[jugador].cartas[i+1];
    }
    jugadores[jugador].num_cartas--;
    jugadores[jugador].puntos = calcular_puntos(jugador);
}

int tiene_carta_especial_mas_alta() {
    int max_valor = 0;
    int ganador = -1;
    for (int i = 0; i < num_jugadores; i++) {
        if (!jugadores[i].eliminado) {
            for (int j = 0; j < jugadores[i].num_cartas; j++) {
                int v = jugadores[i].cartas[j].valor;
                if (v == 13 || v == 12 || v == 11) {
                    if (v > max_valor) {
                        max_valor = v;
                        ganador = i;
                    }
                }
            }
        }
    }
    return ganador;
}


void verificar_todos_eliminados() {
    int todos_eliminados = 1;
    for (int i = 0; i < num_jugadores; i++) {
        if (!jugadores[i].eliminado) {
            todos_eliminados = 0; //
            break;
        }
    }
    if (todos_eliminados) {
        printf("\nTodos perdieron xD\n");
        juego_terminado = 1;
}
}
// el juego
int main() {
    srand(time(NULL));

    printf(BLUE
"    ____  ___    __    ___  __________  __  ___   ______________\n"
"   / __ )/   |  / /   /   |/_  __/ __ \\/ / / / | / / ____/_  __/\n"
"  / __  / /| | / /   / /| | / / / /_/ / / / /  |/ / __/   / /   \n"
" / /_/ / ___ |/ /___/ ___ |/ / / __ _/ /_/ / /|  / /___  / /    \n"
"/_____/_/  |_/_____/_/  |_/_/ /_/ |_|\\____/_/ |_/_____/ /_/     \n"
"                                                                 \n"
"\n"
RESET);

    do {
        printf("Ingrese numero de jugadores (%d-%d): ", MIN_JUGADORES, MAX_JUGADORES);
        scanf("%d", &num_jugadores);
    } while (num_jugadores < MIN_JUGADORES || num_jugadores > MAX_JUGADORES);
    system("cls");
    printf(BLUE"\t ___ ___ ___ _      _   ___ \n"
    "        | _ \\ __/ __| |    /_\\ / __|\n"
    "        |   / _| (_ | |__ / _ \\\\__ \\\n"
    "        |_|_\\___\\___|____/_/ \\_\\___/\n"
    "                             \n\n");
        printf(WHITE"se van a repartir 2 cartas a cada jugador aleatoriamente\n");
        printf(WHITE"en tu turno tienes tres opciones:\n\n");
        printf(MAGENTA"1)Draw: ");
            printf(WHITE"Pedir una carta al crupier\n");
        printf(YELLOW"2)Stand: ");
            printf(WHITE"Quedarse con la suma actual y pasar al siguiente turno.\n");
        printf(GREEN"3)Hit: ");
            printf(WHITE"Usar una carta especial (se aplica al jugador del siguiente turno).\n\n");
        printf("El objetivo del juego es llegar a 21 puntos o lo mas cercano posible sin pasarse, ");
        printf("Si te pasas de 21 pierdes automaticamente.\n");
        printf("La ronda acaba si un jugador consigue tener 21.\n");
        printf("si hay empate, el ganador se decidira por quien tenga la carta especial mas alta.\n\n");
        printf(BLUE"presiona cualquier tecla para continuar\n");
        getch();


        system("cls");
            printf(
"   ___   _   ___ _____ _   ___   ___ ___ ___ ___ ___ ___   _   _    ___ ___ \n"
"  / __| /_\\ | _ \\_   _/_\\ / __| | __/ __| _ \\ __/ __|_ _| /_\\ | |  | __/ __|\n"
" | (__ / _ \\|   / | |/ _ \\\\__ \\ | _|\\__ \\  _/ _| (__ | | / _ \\| |__| _|\\__ \\\n"
"  \\___/_/ \\_\\_|_\\ |_/_/ \\_\\___/ |___|___/_| |___\\___|___/_/ \\_\\____|___|___/\n\n"
);
            printf(WHITE"Ahora se van a mostrar las cartas especiales segun su valor en orden decreciente:\n\n");
            printf(YELLOW"1. King (K): ");
                printf(WHITE"Salta un turno.\n");
            printf(MAGENTA"2. Queen (Q): ");
                printf(WHITE"cambia la direccion de la ronda.\n");
            printf(RED"3. Joker (J): ");
                printf(WHITE"Si el siguiente jugador tiene una cantidad par de cartas,\nes penalizado con +2 cartas, si es impar es penalizado con +4 cartas.\n\n");
            printf("Es importante acotar que solo se puede aplicar una carta especial por turno.\n\n");
            printf(BLUE"presiona cualquier tecla para continuar\n");
            getch();
        



        system("cls");
    for (int i = 0; i < num_jugadores; i++) {
        jugadores[i].num_cartas = 0;
        jugadores[i].eliminado = 0;
        jugadores[i].puntos = 0;
        jugadores[i].carta_especial_usada = 0;
    }

    for (int i = 0; i < num_jugadores; i++) {
        repartir_carta(i);
        repartir_carta(i);
        jugadores[i].puntos = calcular_puntos(i);
    }

    while (!juego_terminado) {
        if (jugadores[turno_actual].eliminado) {
            siguiente_turno();
            continue;
        }

        mostrar_estado();

        printf(BLUE "\nTurno jugador %d\n" RESET, turno_actual + 1);
        printf("Opciones:\n\n");
        printf("1) Draw (Pedir carta)\n");
        printf("2) Stand (Pasar turno)\n");
        printf("3) Hit (Usar carta especial para siguiente jugador)\n");
        int opcion;
        do {
            printf("Elige una opcion (1-3): ");
            scanf("%d", &opcion);
        } while (opcion < 1 || opcion > 3);

        switch (opcion) {
            case 1:
                repartir_carta(turno_actual);
                jugadores[turno_actual].puntos = calcular_puntos(turno_actual);
                printf("Has pedido una carta.\n");
                mostrar_mano(turno_actual);

                if (jugadores[turno_actual].puntos > 21) {
                    printf(RED "\nTe has pasado de 21. Estas eliminado de la ronda.\n" RESET);
                    jugadores[turno_actual].eliminado = 1;
                } else if (jugadores[turno_actual].puntos == 21) {
                    printf(GREEN "\nHas conseguido 21! La ronda termina.\n" RESET);
                    juego_terminado = 1;
                }
                break;

            case 2:
                printf("Pasas tu turno.\n");
                break;

            case 3:
                if (jugadores[turno_actual].carta_especial_usada) {
                    printf(RED "Ya usaste una carta especial este turno.\n" RESET);
                } else {
                    usar_carta_especial(turno_actual);
                    jugadores[turno_actual].carta_especial_usada = 1;
                }
                break;
        }
system("cls");
verificar_todos_eliminados();
        if (!juego_terminado) {
            siguiente_turno();
        }
    }

    int ganador = -1;
    int max_puntos = 0;
    int empate = 0;

    for (int i = 0; i < num_jugadores; i++) {
        if (!jugadores[i].eliminado && jugadores[i].puntos <= 21) {
            if (jugadores[i].puntos > max_puntos) {
                max_puntos = jugadores[i].puntos;
                ganador = i;
                empate = 0;
            } else if (jugadores[i].puntos == max_puntos && max_puntos > 0) {
                empate = 1;
            }
        }
    }

    if (empate) {
        int ganador_especial = tiene_carta_especial_mas_alta();
        if (ganador_especial >= 0) {
            ganador = ganador_especial;
            printf(MAGENTA "Ganador decidido por carta especial mas alta: Jugador %d\n" RESET, ganador + 1);
        } else {
            printf(RED "Empate total. No hay ganador claro.\n" RESET);
            ganador = -1;
        }
    } else if (ganador >= 0) {
        printf(GREEN "\nEl ganador es el Jugador %d con %d puntos!\n" RESET, ganador + 1, jugadores[ganador].puntos);
    } else {
        printf(RED "No hay ganador en esta ronda.\n" RESET);
    }

    printf("Fin del juego.\n");

    return 0;
}